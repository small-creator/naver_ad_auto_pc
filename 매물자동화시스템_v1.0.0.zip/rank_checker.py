import requests
import json
import time
import os
from typing import Optional, Tuple
from datetime import datetime
import re
from bs4 import BeautifulSoup
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

class NaverRealEstateRanking:
    """네이버부동산 매물 순위 분석 시스템"""
    
    # 상수 정의
    PROPERTIES_PER_PAGE = 20
    ARTICLES_PER_PAGE = 30
    APARTMENT_CODE = "A01"
    
    def __init__(self):
        """클래스 초기화"""
        self.base_url = "https://m.land.naver.com"
        self.fin_url = "https://fin.land.naver.com"
        self.cache_file = "property_cache.json"
        
        # 환경변수에서 기본 회원 ID 가져오기
        self.default_member_id = os.getenv('REALTOR_ID')
        if not self.default_member_id:
            print("❌ REALTOR_ID가 .env 파일에 설정되지 않았습니다.")
            print("💡 .env 파일에 다음과 같이 설정해주세요:")
            print("REALTOR_ID=your_realtor_id")
            print()
            print("🔍 부동산업소 ID 확인 방법:")
            print("1. 네이버부동산 중개업소 페이지 접속")
            print("2. URL에서 rltrMbrId 값 확인")
            print("3. 해당 값을 REALTOR_ID로 설정")
            print()
            
            # GUI 환경에서는 messagebox도 표시
            try:
                import tkinter.messagebox as msgbox
                msgbox.showerror(
                    "설정 오류", 
                    "REALTOR_ID가 .env 파일에 설정되지 않았습니다.\n\n"
                    ".env 파일에 부동산업소 ID를 설정해주세요.\n\n"
                    "예시: REALTOR_ID=your_realtor_id"
                )
            except:
                pass  # tkinter가 없는 환경에서는 무시
            
            input("엔터를 눌러 종료...")
            exit(1)

        print(f"🏢 부동산업소 ID: {self.default_member_id}")

        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.cache = self.load_cache()
    
    def load_cache(self) -> dict:
        """캐시 파일 로드"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def save_cache(self):
        """캐시 파일 저장"""
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(self.cache, f, ensure_ascii=False, indent=2)
    
    def get_my_properties(self, member_id: str = None) -> list:
        """내 광고중인 매물 가져오기 (아파트만)"""
        if member_id is None:
            member_id = self.default_member_id
            
        all_properties = []
        page = 1
        
        print("📋 내 광고중인 매물을 가져오는 중...")
        
        while True:
            url = f"{self.base_url}/agency/info/list"
            params = {
                'rltrMbrId': member_id,
                'tradTpCd': '',
                'atclRletTpCd': '',
                'tradeTypeChange': 'false',
                'page': page
            }
            
            try:
                response = self.session.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                
                if 'list' not in data or not data['list']:
                    break
                
                # 아파트만 필터링 (A01)
                apartments = [
                    {
                        'atclNo': item['atclNo'],
                        'atclNm': item['atclNm'],
                        'tradTpCd': item['tradTpCd'],
                        'tradTpNm': item['tradTpNm'],
                        'prcInfo': item['prcInfo'],
                        'atclRletTpNm': item['atclRletTpNm'],
                        'bildNm': item['bildNm'],
                        'dtlAddr': item.get('dtlAddr', ''),
                        'rletTpCd': item.get('rletTpCd', ''),
                        'atclCfmYmd': item.get('atclCfmYmd', ''),
                        'flrInfo': item.get('flrInfo', '')
                    }
                    for item in data['list']
                    if item.get('rletTpCd') == self.APARTMENT_CODE
                ]
                
                all_properties.extend(apartments)
                print(f"페이지 {page}: {len(apartments)}개 아파트 매물 수집")
                
                if len(data['list']) < self.PROPERTIES_PER_PAGE:
                    break
                    
                page += 1
                time.sleep(0.5)
                
            except requests.exceptions.RequestException as e:
                print(f"❌ 페이지 {page} 요청 실패: {e}")
                break
        
        print(f"✅ 총 {len(all_properties)}개의 아파트 매물을 수집했습니다.")
        return all_properties
    
    def get_complex_info(self, atcl_no: str, atcl_nm: str, bild_nm: str) -> Tuple[Optional[str], Optional[str]]:
        """매물번호로 complex_number, buildingNumber 가져오기"""
        
        # 캐시에서 확인
        if atcl_nm in self.cache and bild_nm in self.cache[atcl_nm]:
            print(f"📦 캐시에서 {atcl_nm} {bild_nm} 정보 사용")
            complex_number = self.cache[atcl_nm]['complex_number']
            building_number = self.cache[atcl_nm][bild_nm]
            return complex_number, building_number
        
        print(f"🔍 {atcl_nm} {bild_nm} 단지 정보 조회 중...")
        
        try:
            url = f"{self.fin_url}/articles/{atcl_no}"
            response = self.session.get(url)
            response.raise_for_status()
            
            # HTML 파싱하여 실제 complex_number와 buildingNumber 추출
            soup = BeautifulSoup(response.text, 'html.parser')
            complex_number = None
            building_number = None
            
            # JavaScript에서 데이터 추출
            scripts = soup.find_all('script')
            for script in scripts:
                if script.string:
                    script_text = script.string
                    
                    # complexNumber 찾기
                    complex_match = re.search(r'complexNumber["\']?\s*:\s*["\']?([^"\'&,}]+)', script_text)
                    if complex_match:
                        complex_number = complex_match.group(1).strip()
                    
                    # buildingNumber 찾기
                    building_match = re.search(r'(?:buildingNumber|dongNumber)["\']?\s*:\s*["\']?([^"\'&,}]+)', script_text)
                    if building_match:
                        building_number = building_match.group(1).strip()
                    
                    # URL 파라미터에서도 찾기
                    if not complex_number:
                        complex_url_match = re.search(r'complexNumber=([^&]+)', script_text)
                        if complex_url_match:
                            complex_number = complex_url_match.group(1).strip()
                    
                    if not building_number:
                        building_url_match = re.search(r'dongNumbers(?:%5B%5D|%5b%5d)?=([^&]+)', script_text)
                        if building_url_match:
                            building_number = building_url_match.group(1).strip()
                            building_number = building_number.replace('%EB%8F%99', '동')
            
            # 추출 실패 시 기본값 사용
            if not complex_number:
                complex_number = atcl_nm
                print(f"⚠️ complex_number를 찾을 수 없어 매물명 사용: {complex_number}")
            
            if not building_number:
                building_number = bild_nm
                print(f"⚠️ building_number를 찾을 수 없어 동명 사용: {building_number}")
            
            print(f"✅ 추출된 정보 - Complex: {complex_number}, Building: {building_number}")
            
            # 캐시에 저장 (중복 저장 방지)
            cache_updated = False
            
            if atcl_nm not in self.cache:
                self.cache[atcl_nm] = {
                    'complex_number': complex_number,
                    'updated_at': datetime.now().isoformat()
                }
                cache_updated = True
            
            if bild_nm not in self.cache[atcl_nm]:
                self.cache[atcl_nm][bild_nm] = building_number
                cache_updated = True
            
            if cache_updated:
                self.save_cache()
                print(f"💾 캐시 업데이트: {atcl_nm} - {bild_nm}")
            
            time.sleep(0.5)
            return complex_number, building_number
            
        except requests.exceptions.RequestException as e:
            print(f"❌ 단지 정보 조회 실패 ({atcl_no}): {e}")
            return None, None
        except Exception as e:
            print(f"❌ 데이터 파싱 실패 ({atcl_no}): {e}")
            return atcl_nm, bild_nm
    
    def _find_article_in_list(self, article_list: list, my_atcl_no: str) -> Optional[int]:
        """articleInfoList에서 내 매물 순위 찾기"""
        for idx, sub_article in enumerate(article_list):
            if sub_article.get('articleDetail', {}).get('articleNumber') == my_atcl_no:
                return idx + 1
        return None
    
    def parse_date(self, date_str: str) -> Optional[str]:
        """날짜 문자열을 표준 형식으로 파싱"""
        if not date_str:
            return None
        
        try:
            # "25.07.08." 형식을 "2025-07-08"로 변환
            if '.' in date_str:
                clean_date = date_str.replace('.', '')
                if len(clean_date) == 6:  # YYMMDD
                    year = '20' + clean_date[:2]
                    month = clean_date[2:4]
                    day = clean_date[4:6]
                    return f"{year}-{month}-{day}"
            # "2025-07-16" 형식은 그대로 사용
            elif '-' in date_str:
                return date_str[:10]  # 시간 부분이 있다면 제거
            
            return None
        except:
            return None
    
    def check_update_needed(self, my_article_info: dict, my_rank: int, my_atcl_no: str) -> bool:
        """광고 업데이트 필요 여부 확인"""
        dup_info = my_article_info.get('duplicatedArticlesInfo', {})
        
        # 단독 매물이면 업데이트 불필요
        if not dup_info:
            return False
        
        # 내 매물의 exposureStartDate 가져오기
        rep_info = my_article_info.get('representativeArticleInfo', {})
        my_exposure_date = None
        
        # 대표 매물이 내 매물인 경우
        if rep_info.get('articleNumber') == my_atcl_no:
            my_exposure_date = rep_info.get('verificationInfo', {}).get('exposureStartDate', '')
        else:
            # articleInfoList에서 내 매물 찾기
            article_list = dup_info.get('articleInfoList', [])
            for article in article_list:
                if article.get('articleDetail', {}).get('articleNumber') == my_atcl_no:
                    my_exposure_date = article.get('verificationInfo', {}).get('exposureStartDate', '')
                    break
        
        if not my_exposure_date:
            return False
        
        # 타업체들의 광고 시작일과 비교 (내 매물 제외)
        article_list = dup_info.get('articleInfoList', [])
        for competitor in article_list:
            # 내 매물은 제외
            competitor_article_no = competitor.get('articleDetail', {}).get('articleNumber', '')
            if competitor_article_no == my_atcl_no:
                continue
            
            competitor_start_date = competitor.get('verificationInfo', {}).get('exposureStartDate', '')
            
            # 경쟁업체가 같은 날 또는 이후 날짜에 광고 시작한 경우
            if competitor_start_date and competitor_start_date >= my_exposure_date:
                # 조건 1: 경쟁업체가 있고, 순위가 1위가 아니고, 같은날/이후 광고시작한 타업체 있음
                if my_rank != 1:
                    return True
                # 조건 2: 경쟁업체가 있고, 순위가 1위지만, 같은날/이후 광고시작한 타업체 있음
                else:
                    return True
        
        return False
    
    def check_floor_disclosure(self, my_flr_info: str, representative_article: dict) -> str:
        """층수 공개 여부 확인 (내 매물이 저/중/고이고 경쟁 매물이 있는 경우만)"""
        if not my_flr_info or "/" not in my_flr_info:
            return ""
        
        my_floor_type = my_flr_info.split("/")[0].strip()
        
        # 내 매물이 저/중/고가 아니면 확인하지 않음
        if my_floor_type not in ["저", "중", "고"]:
            return ""
        
        # 대표 매물의 층수 정보 확인
        floor_detail = representative_article.get('articleDetail', {}).get('floorDetailInfo', {})
        target_floor = floor_detail.get('targetFloor', '')
        
        # targetFloor가 숫자면 층수 공개, 아니면 비공개
        if target_floor and target_floor.isdigit():
            return "O"  # 층수 공개
        else:
            return "X"  # 층수 비공개 (저/중/고)
    
    def get_ranking(self, complex_number: str, building_number: str, trade_type: str, my_atcl_no: str, my_flr_info: str) -> dict:
        """노출순위 조회"""
        print(f"🏆 순위 조회 중: {complex_number} {building_number}")
        
        # 거래 유형 코드 매핑
        trade_type_map = {
            'A1': 'A1',  # 매매
            'B1': 'B1',  # 전세
            'B2': 'B2'   # 월세
        }
        
        try:
            url = f"{self.fin_url}/front-api/v1/complex/article/list"
            params = {
                'complexNumber': complex_number,
                'tradeTypes[]': trade_type_map.get(trade_type, trade_type),
                'dateDescending': 'false',
                'userChannelType': 'PC',
                'page': 0
            }
            
            # 동번호가 있으면 필터 추가
            if building_number and building_number != 'None' and building_number != '':
                params['dongNumbers[]'] = building_number
            
            all_articles = []
            page = 0
            
            # 페이지네이션 처리
            while True:
                params['page'] = page
                response = self.session.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                
                if not data.get('isSuccess') or not data.get('result', {}).get('list'):
                    break
                
                articles = data['result']['list']
                all_articles.extend(articles)
                
                print(f"   페이지 {page}: {len(articles)}개 매물 그룹 수집")
                
                if not data['result'].get('hasNextPage', False):
                    break
                    
                page += 1
                time.sleep(0.3)
            
            total_count = data.get('result', {}).get('totalCount', len(all_articles))
            print(f"   총 {len(all_articles)}개 매물 그룹 수집 완료 (totalCount: {total_count})")
            
            # 내 매물 찾기
            my_rank = None
            my_group_realtors = 0
            is_solo = False
            floor_disclosure = ""
            update_needed = False
            my_article_info = None
            
            for article in all_articles:
                rep_info = article.get('representativeArticleInfo', {})
                dup_info = article.get('duplicatedArticlesInfo', {})
                
                # 대표 매물이 내 매물인지 확인
                if rep_info.get('articleNumber') == my_atcl_no:
                    my_article_info = article
                    if not dup_info:
                        # 단독 매물 (층수오픈 확인 불필요)
                        my_rank = 1
                        is_solo = True
                        my_group_realtors = 1
                        print(f"   ✅ 단독 매물로 발견: 1위 (단독)")
                    else:
                        # 경쟁 매물 존재
                        article_list = dup_info.get('articleInfoList', [])
                        my_group_realtors = dup_info.get('realtorCount', len(article_list) + 1)
                        my_rank = self._find_article_in_list(article_list, my_atcl_no)
                        
                        if my_rank is None:
                            my_rank = 1
                            print(f"   ✅ 대표 매물로 발견: 1위 / {my_group_realtors}개 업체")
                        else:
                            print(f"   ✅ 경쟁 매물에서 발견: {my_rank}위 / {len(article_list)}개 업체")
                        
                        # 층수 공개 여부 확인
                        floor_disclosure = self.check_floor_disclosure(my_flr_info, rep_info)
                        
                        # 업데이트 필요 여부 확인
                        update_needed = self.check_update_needed(article, my_rank, my_atcl_no)
                    break
                
                # 중복 매물 리스트에서도 확인
                if dup_info and 'articleInfoList' in dup_info:
                    article_list = dup_info.get('articleInfoList', [])
                    my_rank = self._find_article_in_list(article_list, my_atcl_no)
                    if my_rank:
                        my_article_info = article
                        my_group_realtors = dup_info.get('realtorCount', len(article_list) + 1)
                        print(f"   ✅ 중복 매물에서 발견: {my_rank}위 / {len(article_list)}개 업체")
                        # 층수 공개 여부 확인
                        floor_disclosure = self.check_floor_disclosure(my_flr_info, rep_info)
                        # 업데이트 필요 여부 확인
                        update_needed = self.check_update_needed(article, my_rank, my_atcl_no)
                        break
            
            if my_rank is None:
                print(f"   ❌ 매물번호 {my_atcl_no}를 찾을 수 없습니다.")
            
            return {
                'rank': my_rank,
                'total_realtors': my_group_realtors,
                'found': my_rank is not None,
                'is_solo': is_solo,
                'floor_disclosure': floor_disclosure,
                'update_needed': update_needed
            }
            
        except requests.exceptions.RequestException as e:
            print(f"❌ 순위 조회 실패: {e}")
            return {'rank': None, 'total_realtors': 0, 'found': False, 'is_solo': False, 'floor_disclosure': '', 'update_needed': False}
    
    def format_price(self, prc_info: str) -> str:
        """가격 정보 포맷팅"""
        if '/' in prc_info:
            # 전세/월세 형태 (예: 90000/180)
            parts = prc_info.split('/')
            if len(parts) == 2:
                deposit = int(parts[0]) if parts[0].isdigit() else 0
                rent = int(parts[1]) if parts[1].isdigit() else 0
                
                if deposit >= 10000:
                    deposit_str = f"{deposit//10000}억"
                    if deposit % 10000 > 0:
                        deposit_str += f" {deposit%10000}만원"
                else:
                    deposit_str = f"{deposit}만원"
                
                return f"{deposit_str}/{rent}만원"
        
        # 매매가 형태
        if prc_info.isdigit():
            price = int(prc_info)
            if price >= 10000:
                return f"{price//10000}억 {price%10000}만원" if price % 10000 > 0 else f"{price//10000}억원"
            else:
                return f"{price}만원"
        
        return prc_info
    
    def get_floor_info(self, bild_nm: str, flr_info: str) -> str:
        """층 정보를 동명과 함께 반환"""
        if not flr_info:
            return bild_nm
        
        # flrInfo에서 층 정보 추출: "저/29", "6/22", "중/15" 등
        if "/" in flr_info:
            floor_part = flr_info.split("/")[0].strip()
            
            # 숫자인 경우: "6/22" -> "6층"
            if floor_part.isdigit():
                return f"{bild_nm} {floor_part}층"
            
            # 저중고인 경우: "저/29" -> "저층"
            elif floor_part in ["저", "중", "고"]:
                return f"{bild_nm} {floor_part}층"
        
        return bild_nm
    
    def print_results(self, results: list):
        """결과 출력 및 파일 저장"""
        output_lines = []
        
        header = "="*80
        title = "🏆 매물 순위 분석 결과"
        
        output_lines.append(header)
        output_lines.append(title)
        output_lines.append(header)
        
        print(f"\n{header}")
        print(title)
        print(header)
        
        for result in results:
            section_lines = []
            
            if result['found']:
                if result['is_solo']:
                    rank_emoji = "👑"
                    rank_text = "단독"
                else:
                    rank_emoji = "🥇" if result['rank'] == 1 else "🥈" if result['rank'] == 2 else "🥉" if result['rank'] == 3 else "🏆"
                    rank_text = f"{result['rank']}위 / {result['total_realtors']}개 업체"
                
                section_lines.append(f"{rank_emoji} 매물명: {result['property_name']} {result['floor_info']}")
                section_lines.append(f"📋 매물번호: {result['article_no']}")
                section_lines.append(f"🏠 매물종류: {result['property_type']}")
                section_lines.append(f"📅 거래종류: {result['trade_type']}")
                section_lines.append(f"💵 가격: {result['price']}")
                section_lines.append(f"📅 광고등록일: {result['register_date']}")
                section_lines.append(f"🏆 순위: {rank_text}")
                
                # 층수 공개 여부 표시 (저/중/고 매물만)
                if result['floor_disclosure']:
                    floor_emoji = "✅" if result['floor_disclosure'] == "O" else "❌"
                    section_lines.append(f"🏢 층수오픈: {floor_emoji}")
            else:
                section_lines.append(f"❌ 매물명: {result['property_name']} {result['floor_info']}")
                section_lines.append(f"📋 매물번호: {result['article_no']}")
                section_lines.append(f"🏠 매물종류: {result['property_type']}")
                section_lines.append(f"📅 거래종류: {result['trade_type']}")
                section_lines.append(f"💵 가격: {result['price']}")
                section_lines.append(f"📅 광고등록일: {result['register_date']}")
                section_lines.append(f"❓ 순위: 조회 실패")
            
            # 콘솔 출력
            print()
            for line in section_lines:
                print(line)
            print("-" * 60)
            
            # 파일 저장용 추가
            output_lines.append("")
            output_lines.extend(section_lines)
            output_lines.append("-" * 60)
        
        # 파일 저장
        self.save_results_to_file(output_lines)
        
        # 요약 분석 추가
        self.print_summary_analysis(results)
    
    def print_summary_analysis(self, results: list):
        """요약 분석 출력"""
        print("\n" + "="*80)
        print("📊 요약 분석")
        print("="*80)
        
        # 업데이트 필요 매물 필터링
        update_needed_properties = [
            result for result in results 
            if result['found'] and result.get('update_needed', False)
        ]
        
        # 층수오픈된 매물 필터링
        floor_disclosed_properties = [
            result for result in results 
            if result['found'] and result.get('floor_disclosure') == 'O'
        ]
        
        if update_needed_properties:
            print(f"\n🔄 업데이트 필요 매물 ({len(update_needed_properties)}개)")
            print("-" * 60)
            
            for prop in update_needed_properties:
                if prop['is_solo']:
                    rank_text = "단독"
                else:
                    rank_text = f"{prop['rank']}위 / {prop['total_realtors']}개 업체"
                
                print(f"🔄 {prop['property_name']} {prop['floor_info']}")
                print(f"   매물번호: {prop['article_no']}")
                print(f"   순위: {rank_text} | 가격: {prop['price']} | 등록일: {prop['register_date']}")
                print(f"   사유: 같은날/이후 경쟁업체 광고 시작")
                print()
        else:
            print("\n🔄 업데이트가 필요한 매물이 없습니다.")
        
        if floor_disclosed_properties:
            print(f"\n🏢 층수오픈 매물 ({len(floor_disclosed_properties)}개)")
            print("-" * 60)
            
            for prop in floor_disclosed_properties:
                if prop['is_solo']:
                    rank_text = "단독"
                else:
                    rank_text = f"{prop['rank']}위 / {prop['total_realtors']}개 업체"
                
                print(f"✅ {prop['property_name']} {prop['floor_info']}")
                print(f"   매물번호: {prop['article_no']}")
                print(f"   순위: {rank_text} | 가격: {prop['price']} | 등록일: {prop['register_date']}")
                print()
        else:
            print("\n🏢 층수오픈된 매물이 없습니다.")
        
        # 업데이트 필요 매물번호 간단 출력
        if update_needed_properties:
            article_numbers = [prop['article_no'] for prop in update_needed_properties]
            print(f"\n🔄 업데이트 필요 매물번호: {', '.join(article_numbers)}")
        
        print("="*80)
    
    def save_results_to_file(self, output_lines: list):
        """결과를 txt 파일로 저장"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"매물순위분석_{timestamp}.txt"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write('\n'.join(output_lines))
            
            print(f"\n💾 결과가 파일로 저장되었습니다: {filename}")
            
        except Exception as e:
            print(f"\n❌ 파일 저장 실패: {e}")
    
    def run_analysis(self, member_id: str = None, test_mode: bool = False, test_count: int = 3):
        """전체 분석 실행"""
        if member_id is None:
            member_id = self.default_member_id
            
        mode_text = f"테스트 모드 (최대 {test_count}개)" if test_mode else "전체 분석"
        print(f"🚀 네이버부동산 매물 순위 {mode_text}을 시작합니다...\n")
        
        # 1. 내 매물 가져오기
        my_properties = self.get_my_properties(member_id)
        
        if not my_properties:
            print("❌ 광고중인 매물이 없습니다.")
            return
        
        # 테스트 모드일 경우 제한
        if test_mode:
            my_properties = my_properties[:test_count]
            print(f"🧪 테스트 모드: 처음 {len(my_properties)}개 매물만 분석합니다.")
        
        print(f"\n📊 총 {len(my_properties)}개 매물의 순위를 분석합니다...\n")
        
        results = []
        
        for i, prop in enumerate(my_properties, 1):
            print(f"[{i}/{len(my_properties)}] 분석 중: {prop['atclNm']} {prop['bildNm']}")
            print(f"📋 매물번호: {prop['atclNo']}")
            print(f"🏢 거래종류: {prop['tradTpNm']} ({prop['tradTpCd']})")
            print(f"💰 가격: {prop['prcInfo']}")
            print(f"📅 광고등록일: {prop['atclCfmYmd']}")
            
            # 2. 단지 정보 가져오기
            complex_number, building_number = self.get_complex_info(
                prop['atclNo'], prop['atclNm'], prop['bildNm']
            )
            
            if not complex_number:
                print("❌ 단지 정보를 가져올 수 없습니다.")
                continue
            
            print(f"🏠 Complex Number: {complex_number}")
            print(f"🏢 Building Number: {building_number}")
            
            # 3. 순위 조회
            ranking_info = self.get_ranking(
                complex_number, building_number, prop['tradTpCd'], prop['atclNo'], prop['flrInfo']
            )
            
            # 4. 결과 정리
            floor_info = self.get_floor_info(prop['bildNm'], prop['flrInfo'])
            formatted_price = self.format_price(prop['prcInfo'])
            
            result = {
                'property_name': prop['atclNm'],
                'floor_info': floor_info,
                'article_no': prop['atclNo'],
                'property_type': prop['atclRletTpNm'],
                'trade_type': prop['tradTpNm'],
                'price': formatted_price,
                'register_date': prop['atclCfmYmd'],
                'rank': ranking_info['rank'],
                'total_realtors': ranking_info['total_realtors'],
                'found': ranking_info['found'],
                'is_solo': ranking_info.get('is_solo', False),
                'floor_disclosure': ranking_info.get('floor_disclosure', ''),
                'update_needed': ranking_info.get('update_needed', False),
                'complex_number': complex_number,
                'building_number': building_number
            }
            
            results.append(result)
            
            if ranking_info['found']:
                print(f"✅ 완료: {result['rank']}위 / {result['total_realtors']}개 업체")
            else:
                print("❌ 순위 조회 실패")
            
            print("-" * 80 + "\n")
            
            time.sleep(1)
        
        # 5. 결과 출력
        self.print_results(results)
        
        return results


def main():
    """메인 실행 함수"""
    try:
        analyzer = NaverRealEstateRanking()
        
        print("🔧 실행 모드를 선택하세요:")
        print("1. 테스트 모드 (3개 매물만)")
        print("2. 전체 분석")
        
        choice = input("\n선택 (1 또는 2): ").strip()
        
        # Member ID 입력받기
        print(f"\n👤 Member ID를 입력하세요 (기본값: {analyzer.default_member_id})")
        member_input = input("Member ID (엔터 시 기본값): ").strip()
        
        member_id = member_input if member_input else analyzer.default_member_id
        print(f"사용할 Member ID: {member_id}")
        
        if choice == "1":
            print("\n🧪 테스트 모드로 실행합니다...\n")
            results = analyzer.run_analysis(member_id=member_id, test_mode=True, test_count=3)
        else:
            print("\n📊 전체 분석 모드로 실행합니다...\n")
            results = analyzer.run_analysis(member_id=member_id, test_mode=False)
        
        # 요약 통계
        if results:
            successful = [r for r in results if r['found']]
            print(f"\n📈 분석 완료: {len(successful)}/{len(results)}개 매물")
            
            if successful:
                avg_rank = sum(r['rank'] for r in successful) / len(successful)
                print(f"📊 평균 순위: {avg_rank:.1f}위")
                
                top_3 = [r for r in successful if r['rank'] <= 3]
                print(f"🏆 상위 3위 매물: {len(top_3)}개")
                
                # 층수 오픈 통계
                floor_disclosed_count = len([r for r in successful if r.get('floor_disclosure') == 'O'])
                floor_hidden_count = len([r for r in successful if r.get('floor_disclosure') == 'X'])
                if floor_disclosed_count + floor_hidden_count > 0:
                    print(f"🏢 층수오픈 현황: ✅{floor_disclosed_count}개, ❌{floor_hidden_count}개")
                
            # 캐시 정보 출력
            print(f"\n📦 캐시 정보:")
            for complex_name, info in analyzer.cache.items():
                dong_count = len([k for k in info.keys() if k not in ['complex_number', 'updated_at']])
                print(f"   {complex_name}: {dong_count}개 동 정보 저장됨")
    
    except KeyboardInterrupt:
        print("\n\n⏹️  분석이 중단되었습니다.")
    except Exception as e:
        print(f"\n❌ 오류가 발생했습니다: {e}")


def test_run(member_id: str = None):
    """간단한 테스트 실행 함수"""
    print("🧪 간단 테스트 실행 중...")
    analyzer = NaverRealEstateRanking()
    
    if member_id is None:
        member_id = analyzer.default_member_id
        print(f"기본 Member ID 사용: {member_id}")
    else:
        print(f"지정된 Member ID 사용: {member_id}")
    
    return analyzer.run_analysis(member_id=member_id, test_mode=True, test_count=3)


if __name__ == "__main__":
    main()