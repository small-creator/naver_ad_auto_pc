import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
import threading
import time
import subprocess
from datetime import datetime, timedelta
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()


class LoadingSpinner:
    def __init__(self, parent, text="로딩 중..."):
        self.parent = parent
        self.text = text
        self.running = False
        self.spinner_chars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        self.current_char = 0

    def start(self, label):
        """스피너 시작"""
        self.label = label
        self.running = True
        self._animate()

    def stop(self):
        """스피너 중지"""
        self.running = False

    def _animate(self):
        """스피너 애니메이션"""
        if self.running:
            spinner_char = self.spinner_chars[self.current_char]
            self.label.config(text=f"{spinner_char} {self.text}")
            self.current_char = (self.current_char +
                                 1) % len(self.spinner_chars)

            # 100ms 후 다음 프레임
            self.parent.after(100, self._animate)


class SimplePropertyManager:
    def __init__(self):
        # 데이터 파일
        self.ranking_data_file = "ranking_data.json"
        
        # GitHub 관련 설정 (환경변수에서 가져오기)
        github_path = os.getenv('GITHUB_REPO_PATH')
        if not github_path:
            print("❌ GITHUB_REPO_PATH가 .env 파일에 설정되지 않았습니다.")
            print("💡 .env 파일에 다음과 같이 설정해주세요:")
            print("GITHUB_REPO_PATH=C:\\Users\\사용자명\\Desktop\\cursor\\github_repos\\저장소명")
            print()
            messagebox.showerror("설정 오류", "GITHUB_REPO_PATH가 .env 파일에 설정되지 않았습니다.\n\n.env 파일을 확인해주세요.")
            input("엔터를 눌러 종료...")
            exit(1)

        self.github_repo_path = github_path
        self.data_folder = os.path.join(self.github_repo_path, "data")
        self.schedule_file = os.path.join(self.data_folder, "scheduled_properties.json")

        print(f"📁 GitHub 저장소 경로: {self.github_repo_path}")

        # 경로 유효성 검사
        if not os.path.exists(self.github_repo_path):
            print(f"⚠️ 경고: GitHub 저장소 경로가 존재하지 않습니다: {self.github_repo_path}")
            print("💡 경로를 확인하거나 install.bat을 다시 실행해주세요.")
            
            result = messagebox.askyesno(
                "경로 오류", 
                f"GitHub 저장소 경로가 존재하지 않습니다:\n{self.github_repo_path}\n\n"
                "그래도 계속 진행하시겠습니까?\n"
                "(예약 기능은 사용할 수 없습니다)"
            )
            
            if not result:
                exit(1)

        # GUI 초기화
        self.root = tk.Tk()
        self.setup_gui()

        # 매물 선택 상태
        self.property_selections = {}

        # 층수 오픈 매물 리스트
        self.floor_open_properties = []
        
        # 정렬 상태 관리
        self.sort_reverse = False  # False: 내림차순, True: 오름차순

    def setup_gui(self):
        """GUI 설정"""
        self.root.title("🏆 매물 광고 자동화 관리 시스템")
        
        # 화면 중앙 배치
        width = 1000
        height = 650
        
        # 화면 크기 가져오기
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # 중앙 좌표 계산
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        
        # 중앙에 배치
        self.root.geometry(f"{width}x{height}+{x}+{y}")

        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 제목
        title_label = ttk.Label(main_frame, text="🏆 매물 광고 자동화 관리 시스템",
                                font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=10)

        # GitHub Actions 안내
        info_frame = ttk.LabelFrame(main_frame, text="📋 사용 안내", padding="10")
        info_frame.grid(row=1, column=0, columnspan=3, pady=5, sticky=(tk.W, tk.E))
        
        info_text = "🚀 최적화 예약은 매일 자정 1분에 매물 광고 자동 실행됩니다."
        ttk.Label(info_frame, text=info_text, font=("Arial", 10), 
                 foreground="blue").pack()

        # 상태 표시
        self.status_label = ttk.Label(
            main_frame, text="시스템 준비됨", font=("Arial", 12))
        self.status_label.grid(row=2, column=0, columnspan=3, pady=5)

        self.schedule_status = ttk.Label(main_frame, text="예약된 작업 없음",
                                         font=("Arial", 10), foreground="gray")
        self.schedule_status.grid(row=3, column=0, columnspan=3, pady=5)

        # 로딩 스피너 초기화
        self.spinner = LoadingSpinner(self.root)

        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=3, pady=10)

        ttk.Button(button_frame, text="📊 순위 조회",
                   command=self.run_ranking_analysis, width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="🚀 즉시 실행",
                   command=self.real_automation, width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="⏰ 최적화 예약",
                   command=self.schedule_midnight_automation, width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="❌ 예약 취소",
                   command=self.cancel_schedule, width=15).pack(side=tk.LEFT, padx=5)

        # 매물 리스트 프레임
        list_frame = ttk.LabelFrame(main_frame, text="매물 목록", padding="10")
        list_frame.grid(row=5, column=0, columnspan=3, pady=10,
                        sticky=(tk.W, tk.E, tk.N, tk.S))

        # 매물 리스트 내부 버튼 프레임 (전체선택/해제)
        list_button_frame = ttk.Frame(list_frame)
        list_button_frame.grid(
            row=0, column=0, columnspan=2, pady=(0, 5), sticky=(tk.W))

        ttk.Button(list_button_frame, text="☑️ 전체 선택",
                   command=self.select_all, width=12).pack(side=tk.LEFT, padx=5)
        ttk.Button(list_button_frame, text="☐ 전체 해제",
                   command=self.deselect_all, width=12).pack(side=tk.LEFT, padx=5)

        # 트리뷰 설정
        columns = ("선택", "매물명", "매물번호", "종류",
                   "가격", "광고등록일", "순위", "상태", "층수오픈")
        self.tree = ttk.Treeview(
            list_frame, columns=columns, show="headings", height=12)

        # 컬럼 헤더 설정 및 클릭 이벤트
        for col in columns:
            if col == "광고등록일":
                self.tree.heading(col, text=f"{col} ↓", command=lambda: self.sort_by_register_date())
            else:
                self.tree.heading(col, text=col)

        # 컬럼 너비 및 정렬 설정
        self.tree.column("선택", width=40, anchor="center")
        self.tree.column("매물명", width=250)
        self.tree.column("매물번호", width=80, anchor="center")
        self.tree.column("종류", width=60, anchor="center")
        self.tree.column("가격", width=120)
        self.tree.column("광고등록일", width=80, anchor="center")
        self.tree.column("순위", width=80, anchor="center")
        self.tree.column("상태", width=100)
        self.tree.column("층수오픈", width=80, anchor="center")

        # 트리뷰 스타일 설정
        style = ttk.Style()
        style.configure("Treeview", rowheight=25, font=("Arial", 9))
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"))

        # 시각적 차이를 위한 태그 설정
        self.tree.tag_configure(
            'update_needed', background='#FFE4E1')    # 연한 빨강 (업데이트 필요)
        self.tree.tag_configure(
            'floor_open', background='#E1F5FE')       # 연한 파랑 (층수 오픈)
        self.tree.tag_configure(
            'both', background='#F3E5F5')             # 연한 보라 (둘 다)
        self.tree.tag_configure('normal', background='white')             # 일반

        # 선택된 매물용 태그
        self.tree.tag_configure(
            'selected', background='#B2DFDB')         # 연한 청록색 (선택된 매물)

        # 스크롤바 (가로/세로 모두 추가)
        scrollbar_y = ttk.Scrollbar(
            list_frame, orient=tk.VERTICAL, command=self.tree.yview)
        scrollbar_x = ttk.Scrollbar(
            list_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=scrollbar_y.set,
                            xscrollcommand=scrollbar_x.set)

        self.tree.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar_y.grid(row=1, column=1, sticky=(tk.N, tk.S))
        scrollbar_x.grid(row=2, column=0, sticky=(tk.W, tk.E))

        # 트리뷰 클릭 이벤트
        self.tree.bind("<Button-1>", self.on_tree_click)

        # 그리드 가중치 설정
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(5, weight=1)  # 매물 리스트
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(1, weight=1)
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

        # 기존 데이터 로드
        self.load_existing_data()

    def get_item_tag(self, prop, is_selected=False):
        """매물의 상태에 따른 태그 결정"""
        if is_selected:
            return "selected"
        else:
            update_needed = prop.get('update_needed', False)
            floor_open = prop.get('floor_disclosure') == 'O'

            if update_needed and floor_open:
                return "both"
            elif update_needed:
                return "update_needed"
            elif floor_open:
                return "floor_open"
            else:
                return "normal"

    def run_ranking_analysis(self):
        """순위 분석 실행"""
        self.spinner.text = "📊 순위 조회 중... 시간이 걸릴 수 있습니다"
        self.spinner.start(self.status_label)
        self.set_buttons_state('disabled')

        # 기존 데이터 삭제 및 초기화
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.property_selections.clear()
        self.floor_open_properties = []

        def analysis_thread():
            try:
                from rank_checker import NaverRealEstateRanking
                analyzer = NaverRealEstateRanking()
                results = self.run_analysis_with_realtime_update(analyzer)

                with open(self.ranking_data_file, 'w', encoding='utf-8') as f:
                    json.dump(results, f, ensure_ascii=False, indent=2)

                self.root.after(
                    0, lambda: self.finish_ranking_analysis(results, None))

            except Exception as e:
                error_msg = f"순위 조회 실패: {str(e)}"
                self.root.after(
                    0, lambda: self.finish_ranking_analysis(None, error_msg))

        threading.Thread(target=analysis_thread, daemon=True).start()

    def run_analysis_with_realtime_update(self, analyzer):
        """실시간 업데이트가 가능한 순위 분석"""
        print("🚀 실시간 매물 분석 시작...")

        my_properties = analyzer.get_my_properties()

        if not my_properties:
            self.root.after(0, lambda: self.spinner.stop())
            raise Exception("광고중인 매물이 없습니다.")

        print(f"📋 총 {len(my_properties)}개 매물 분석 시작")
        results = []

        def sort_key(prop):
            return (prop.get('property_name', ''), prop.get('bildNm', ''))

        sorted_properties = sorted(my_properties, key=sort_key)

        for i, prop in enumerate(sorted_properties, 1):
            try:
                print(f"\n[{i}/{len(sorted_properties)}] 분석 중: {prop['atclNm']} {prop['bildNm']}")

                progress_text = f"📊 순위 조회 중... ({i}/{len(sorted_properties)}) {prop['atclNm']}"
                self.root.after(0, lambda t=progress_text: setattr(
                    self.spinner, 'text', t))

                complex_number, building_number = analyzer.get_complex_info(
                    prop['atclNo'], prop['atclNm'], prop['bildNm']
                )

                if not complex_number:
                    print("❌ 단지 정보를 가져올 수 없습니다.")
                    continue

                ranking_info = analyzer.get_ranking(
                    complex_number,
                    building_number,
                    prop['tradTpCd'],
                    prop['atclNo'],
                    prop['flrInfo']
                )

                floor_info = analyzer.get_floor_info(
                    prop['bildNm'], prop['flrInfo'])
                formatted_price = analyzer.format_price(prop['prcInfo'])

                result = {
                    'property_name': prop['atclNm'],
                    'floor_info': floor_info,
                    'article_no': prop['atclNo'],
                    'property_type': prop['atclRletTpNm'],
                    'trade_type': prop['tradTpNm'],
                    'price': formatted_price,
                    'register_date': prop['atclCfmYmd'],
                    'rank': ranking_info['rank'],
                    'total_realtors': ranking_info['total_realtors'],
                    'found': ranking_info['found'],
                    'is_solo': ranking_info.get('is_solo', False),
                    'floor_disclosure': ranking_info.get('floor_disclosure', ''),
                    'update_needed': ranking_info.get('update_needed', False),
                    'complex_number': complex_number,
                    'building_number': building_number
                }

                results.append(result)
                self.root.after(0, lambda r=result: self.add_property_to_gui(r))

                if ranking_info['found']:
                    print(f"✅ 완료: {result['rank']} / {result['total_realtors']} 업체")
                else:
                    print("❌ 순위 조회 실패")

            except Exception as e:
                print(f"❌ 매물 {prop['atclNo']} 분석 실패: {e}")
                continue

        floor_open_properties = [
            prop for prop in results
            if prop.get('floor_disclosure') == 'O'
        ]
        self.floor_open_properties = floor_open_properties

        print(f"\n📊 전체 분석 완료: {len(results)}개 매물 (층수오픈: {len(floor_open_properties)}개)")
        return results

    def add_property_to_gui(self, prop):
        """GUI에 매물 하나씩 실시간 추가"""
        try:
            if prop['found']:
                if prop['is_solo']:
                    rank_text = "👑 단독"
                else:
                    rank_text = f"{prop['rank']} / {prop['total_realtors']}"
            else:
                rank_text = "❌ 조회실패"

            floor_open_text = ""
            if prop.get('floor_disclosure') == 'O':
                floor_open_text = "🏢 오픈"
            else:
                floor_open_text = "-"

            status_text = ""
            if prop.get('update_needed', False):
                status_text = "🔄 업데이트필요"

            is_selected = False
            select_text = "☐"

            tag = ""
            update_needed = prop.get('update_needed', False)
            floor_open = prop.get('floor_disclosure') == 'O'

            if update_needed and floor_open:
                tag = "both"
            elif update_needed:
                tag = "update_needed"
            elif floor_open:
                tag = "floor_open"
            else:
                tag = "normal"

            insert_position = "end"
            if prop.get('update_needed', False):
                update_needed_count = 0
                for item in self.tree.get_children():
                    values = self.tree.item(item, "values")
                    if "🔄" in values[7]:
                        update_needed_count += 1

                if update_needed_count == 0:
                    insert_position = 0
                else:
                    insert_position = update_needed_count

            item_id = self.tree.insert("", insert_position, values=(
                select_text,
                f"{prop['property_name']} {prop['floor_info']}",
                prop['article_no'],
                prop['trade_type'],
                prop['price'],
                prop.get('register_date', '-'),
                rank_text,
                status_text,
                floor_open_text
            ), tags=(tag,))

            self.property_selections[item_id] = {
                'selected': is_selected,
                'article_no': prop['article_no'],
                'property_data': prop
            }

            self.tree.see(item_id)

            # 로그 메시지 개선
            floor_status = "🏢 층수오픈" if prop.get('floor_disclosure') == 'O' else "📋 일반매물"
            print(f"{floor_status}: {prop['property_name']} ({rank_text})")

        except Exception as e:
            print(f"❌ GUI 추가 실패: {e}")

    def finish_ranking_analysis(self, results, error_msg):
        """순위 분석 완료 처리"""
        self.spinner.stop()
        self.set_buttons_state('normal')

        if error_msg:
            self.status_label.config(text=f"❌ {error_msg}")
            messagebox.showerror("오류", error_msg)
        else:
            self.update_property_list(results)
            self.status_label.config(text=f"✅ 순위 조회 완료 ({len(results)}개 매물)")

    def set_buttons_state(self, state):
        """모든 버튼의 활성화/비활성화 상태 설정"""
        try:
            for widget in self.root.winfo_children():
                if isinstance(widget, ttk.Frame):
                    for child in widget.winfo_children():
                        if isinstance(child, ttk.Frame):
                            for button in child.winfo_children():
                                if isinstance(button, ttk.Button):
                                    button.config(state=state)
        except:
            pass

    def sort_by_register_date(self):
        """광고등록일 클릭 시 정렬 변경 (순수하게 날짜만으로 정렬)"""
        # 정렬 방향 전환
        self.sort_reverse = not self.sort_reverse
        
        # 헤더 화살표 변경
        arrow = "↑" if self.sort_reverse else "↓"
        self.tree.heading("광고등록일", text=f"광고등록일 {arrow}")
        
        # 현재 트리뷰의 모든 데이터 가져오기
        items = []
        for item_id in self.tree.get_children():
            values = self.tree.item(item_id, "values")
            prop_data = self.property_selections[item_id]['property_data']
            items.append({
                'item_id': item_id,
                'values': values,
                'prop_data': prop_data,
                'selected': self.property_selections[item_id]['selected'],
                'article_no': self.property_selections[item_id]['article_no']
            })
        
        # 순수하게 광고등록일만으로 정렬
        def sort_key(item):
            register_date = item['prop_data'].get('register_date', '00.00.00.')
            
            # 날짜를 정렬 가능한 형태로 변환
            try:
                if register_date and '.' in register_date:
                    clean_date = register_date.replace('.', '')
                    if len(clean_date) >= 6:
                        year = '20' + clean_date[:2]
                        month = clean_date[2:4]
                        day = clean_date[4:6]
                        formatted_date = f"{year}{month}{day}"
                    else:
                        formatted_date = "20000101"
                else:
                    formatted_date = "20000101"
            except:
                formatted_date = "20000101"
            
            # 순수하게 날짜만으로 정렬 (업데이트 필요 여부 무시)
            if self.sort_reverse:  # 오름차순
                return int(formatted_date)
            else:  # 내림차순
                return -int(formatted_date)
        
        # 정렬 실행
        sorted_items = sorted(items, key=sort_key)
        
        # 트리뷰 다시 구성
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        self.property_selections.clear()
        
        for item_data in sorted_items:
            prop_data = item_data['prop_data']
            is_selected = item_data['selected']
            
            # 태그 결정
            tag = self.get_item_tag(prop_data, is_selected)
            
            # 새 아이템 생성
            new_item_id = self.tree.insert("", "end", values=item_data['values'], tags=(tag,))
            
            # 선택 상태 복원
            self.property_selections[new_item_id] = {
                'selected': is_selected,
                'article_no': item_data['article_no'],
                'property_data': prop_data
            }
        
        print(f"🔄 광고등록일 {'오름차순' if self.sort_reverse else '내림차순'} 정렬 완료")

    def update_property_list(self, results):
        """매물 리스트 업데이트 (업데이트 필요 매물 우선, 그 다음 등록일 내림차순)"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.property_selections.clear()

        self.floor_open_properties = [
            prop for prop in results
            if prop.get('floor_disclosure') == 'O'
        ]

        # 기본 정렬: 업데이트 필요 매물 우선, 그 다음 등록일 내림차순
        def sort_key(prop):
            register_date = prop.get('register_date', '00.00.00.')
            update_needed = prop.get('update_needed', False)
            
            # 날짜를 정렬 가능한 형태로 변환
            try:
                if register_date and '.' in register_date:
                    clean_date = register_date.replace('.', '')
                    if len(clean_date) >= 6:
                        year = '20' + clean_date[:2]
                        month = clean_date[2:4]
                        day = clean_date[4:6]
                        formatted_date = f"{year}{month}{day}"
                    else:
                        formatted_date = "20000101"
                else:
                    formatted_date = "20000101"
            except:
                formatted_date = "20000101"
            
            # 업데이트 필요한 매물 우선, 그 다음 등록일 내림차순(최신순)
            return (not update_needed, -int(formatted_date))

        sorted_results = sorted(results, key=sort_key)
        
        # 초기 정렬 상태 설정 (내림차순)
        self.sort_reverse = False
        self.tree.heading("광고등록일", text="광고등록일 ↓")

        for prop in sorted_results:
            if prop['found']:
                if prop['is_solo']:
                    rank_text = "👑 단독"
                else:
                    rank_text = f"{prop['rank']} / {prop['total_realtors']} 업체"
            else:
                rank_text = "❌ 조회실패"

            floor_open_text = ""
            if prop.get('floor_disclosure') == 'O':
                floor_open_text = "🏢 오픈"
            else:
                floor_open_text = "-"

            status_text = ""
            if prop.get('update_needed', False):
                status_text = "🔄 업데이트필요"

            is_selected = False
            select_text = "☐"

            tag = ""
            update_needed = prop.get('update_needed', False)
            floor_open = prop.get('floor_disclosure') == 'O'

            if update_needed and floor_open:
                tag = "both"
            elif update_needed:
                tag = "update_needed"
            elif floor_open:
                tag = "floor_open"
            else:
                tag = "normal"

            item_id = self.tree.insert("", "end", values=(
                select_text,
                f"{prop['property_name']} {prop['floor_info']}",
                prop['article_no'],
                prop['trade_type'],
                prop['price'],
                prop.get('register_date', '-'),
                rank_text,
                status_text,
                floor_open_text
            ), tags=(tag,))

            self.property_selections[item_id] = {
                'selected': is_selected,
                'article_no': prop['article_no'],
                'property_data': prop
            }

        print(f"📋 매물 리스트 업데이트 완료: {len(sorted_results)}개")

    def select_all(self):
        """전체 매물 선택"""
        selected_count = 0

        for item_id, data in self.property_selections.items():
            if not data['selected']:
                data['selected'] = True

                values = list(self.tree.item(item_id, "values"))
                values[0] = "☑️"
                self.tree.item(item_id, values=values)
                self.tree.item(item_id, tags=("selected",))
                selected_count += 1

        total_selected = sum(
            1 for data in self.property_selections.values() if data['selected'])
        self.status_label.config(text=f"✅ 전체 선택 완료: {total_selected}개 매물")
        print(f"✅ 전체 매물 선택됨: {total_selected}개")

    def deselect_all(self):
        """전체 매물 선택 해제"""
        deselected_count = 0

        for item_id, data in self.property_selections.items():
            if data['selected']:
                data['selected'] = False

                values = list(self.tree.item(item_id, "values"))
                values[0] = "☐"
                self.tree.item(item_id, values=values)

                prop_data = data['property_data']
                original_tag = self.get_item_tag(prop_data, False)
                self.tree.item(item_id, tags=(original_tag,))

                deselected_count += 1

        self.status_label.config(text=f"☐ 전체 선택 해제 완료: {deselected_count}개 매물 해제됨")
        print(f"☐ 전체 매물 선택 해제됨: {deselected_count}개")

    def on_tree_click(self, event):
        """트리뷰 클릭으로 선택 토글"""
        # 클릭 영역 확인
        region = self.tree.identify_region(event.x, event.y)
        # 셀 영역이 아니면 무시 (헤더, 여백 등)
        if region != "cell":
            return
            
        item = self.tree.identify_row(event.y)

        if item and item in self.property_selections:
            current_state = self.property_selections[item]['selected']
            new_state = not current_state
            self.property_selections[item]['selected'] = new_state

            values = list(self.tree.item(item, "values"))
            values[0] = "☑️" if new_state else "☐"
            self.tree.item(item, values=values)

            prop_data = self.property_selections[item]['property_data']
            new_tag = self.get_item_tag(prop_data, new_state)
            self.tree.item(item, tags=(new_tag,))

            selected_count = sum(
                1 for data in self.property_selections.values() if data['selected'])
            self.status_label.config(text=f"선택된 매물: {selected_count}개")

            article_no = self.property_selections[item]['article_no']
            action = "선택" if new_state else "해제"
            print(f"🖱️ 매물 {action}: {article_no}")

        else:
            selected_count = sum(
                1 for data in self.property_selections.values() if data['selected'])
            if selected_count > 0:
                self.status_label.config(text=f"선택된 매물: {selected_count}개")
            else:
                self.status_label.config(text="선택된 매물이 없습니다")

    def schedule_midnight_automation(self):
        """GitHub Actions 예약 (JSON 파일 생성 및 Git push)"""
        selected_properties = [
            data['article_no'] for data in self.property_selections.values()
            if data['selected']
        ]

        if not selected_properties:
            messagebox.showwarning("경고", "선택된 매물이 없습니다.")
            return

        # 내일 자정 1분 시간 계산
        target_time = datetime.now().replace(hour=0, minute=1, second=0, microsecond=0) + timedelta(days=1)

        # 확인 대화상자
        result = messagebox.askyesno(
            "매물광고 최적화 예약",
            f"🚀 매물광고 최적화 예약\n\n"
            f"📅 실행 시간: {target_time.strftime('%Y-%m-%d %H:%M')} \n"
            f"📋 선택된 매물: {len(selected_properties)}개\n"
            f"📊 매물번호: {', '.join(selected_properties)}\n\n"

            f"매물광고 최적화 예약을 진행하시겠습니까?"
        )

        if not result:
            return

        try:
            self.create_github_schedule(target_time, selected_properties)
        except Exception as e:
            messagebox.showerror("오류", f"GitHub 전달 실패: {e}")

    def create_github_schedule(self, target_time, selected_properties):
        """GitHub에 예약 정보 생성 및 전달"""
        try:
            # data 폴더 생성 (없는 경우)
            os.makedirs(self.data_folder, exist_ok=True)

            # JSON 데이터 생성
            schedule_data = {
                'properties': selected_properties,
                'total_count': len(selected_properties),
                'scheduled_at': datetime.now().isoformat(),
                'target_time': target_time.isoformat(),
                'schedule_type': 'github_actions',
                'created_from': 'local_gui'
            }

            # JSON 파일 저장
            with open(self.schedule_file, 'w', encoding='utf-8') as f:
                json.dump(schedule_data, f, ensure_ascii=False, indent=2)

            print(f"📄 JSON 파일 생성: {self.schedule_file}")
            print(f"📊 매물 개수: {len(selected_properties)}")
            print(f"📋 매물번호: {', '.join(selected_properties)}")

            # Git 작업 실행
            self.git_commit_and_push(selected_properties)

            # 상태 업데이트
            status_text = f"🚀 최적화 예약 완료: {len(selected_properties)}개 매물 예약됨"
            self.schedule_status.config(text=status_text)

            messagebox.showinfo("완료", 
                f"매물광고 최적화 예약 완료!\n\n"
                f"📅 실행 시간: {target_time.strftime('%Y-%m-%d %H:%M')} \n"
                f"📋 매물 개수: {len(selected_properties)}개\n"
                f"📊 매물번호: {', '.join(selected_properties)}\n\n"
                f"🚀 GitHub Actions에서 자동으로 실행됩니다!"
            )

        except Exception as e:
            raise Exception(f"예약 파일 생성 실패: {e}")

    def git_commit_and_push(self, selected_properties):
        """Git add, commit, push 실행"""
        try:
            # 현재 디렉토리 저장
            original_dir = os.getcwd()
            
            # Git 저장소로 이동
            os.chdir(self.github_repo_path)
            print(f"📁 Git 저장소로 이동: {self.github_repo_path}")
            
            # Git 사용자 설정 확인 및 설정
            try:
                result = subprocess.run(['git', 'config', 'user.email'], 
                                      capture_output=True, text=True, check=False)
                if not result.stdout.strip():
                    # 사용자 정보 설정 (필요시 실제 정보로 수정)
                    subprocess.run(['git', 'config', 'user.email', 'automation@local.com'], 
                                 check=True)
                    subprocess.run(['git', 'config', 'user.name', 'Property Automation'], 
                                 check=True)
                    print("✅ Git 사용자 정보 설정 완료")
            except:
                # 전역 설정으로 fallback
                subprocess.run(['git', 'config', '--global', 'user.email', 'automation@local.com'], 
                             check=False)
                subprocess.run(['git', 'config', '--global', 'user.name', 'Property Automation'], 
                             check=False)
            
            # Git add
            result = subprocess.run(['git', 'add', 'data/scheduled_properties.json'], 
                         check=True, capture_output=True, text=True, encoding='utf-8')
            print("✅ Git add 완료")

            # Git commit
            commit_message = f"🤖 자동화 예약: {len(selected_properties)}개 매물 ({datetime.now().strftime('%Y-%m-%d %H:%M')})"
            result = subprocess.run(['git', 'commit', '-m', commit_message], 
                         check=True, capture_output=True, text=True, encoding='utf-8')
            print("✅ Git commit 완료")

            # Git push
            result = subprocess.run(['git', 'push'], 
                         check=True, capture_output=True, text=True, encoding='utf-8')
            print("✅ Git push 완료")

            print(f"🚀 최적화 예약 완료!")

        except subprocess.CalledProcessError as e:
            error_msg = f"Git 명령어 실행 실패: {e.stderr if e.stderr else str(e)}"
            print(f"❌ {error_msg}")
            raise Exception(error_msg)

        except Exception as e:
            error_msg = f"Git 작업 중 오류: {str(e)}"
            print(f"❌ {error_msg}")
            raise Exception(error_msg)
        finally:
            # 원래 디렉토리로 복원
            os.chdir(original_dir)

    def cancel_schedule(self):
        """GitHub 예약 취소 (scheduled_properties.json 삭제)"""
        try:
            # 예약 파일이 있는지 확인
            if not os.path.exists(self.schedule_file):
                messagebox.showinfo("정보", "취소할 예약이 없습니다.")
                return

            # 기존 예약 정보 읽기
            try:
                with open(self.schedule_file, 'r', encoding='utf-8') as f:
                    schedule_data = json.load(f)
                property_count = len(schedule_data.get('properties', []))
                scheduled_time = schedule_data.get('target_time', '')
                
                # ISO 형식 시간을 읽기 쉬운 형식으로 변환
                if scheduled_time:
                    try:
                        dt = datetime.fromisoformat(scheduled_time)
                        scheduled_time = dt.strftime('%Y-%m-%d %H:%M')
                    except:
                        pass
            except:
                property_count = 0
                scheduled_time = "알 수 없음"

            # 확인 대화상자
            result = messagebox.askyesno(
                "최적화 예약 취소 확인",
                f"🗑️ 매물광고 최적화 예약을 취소하시겠습니까?\n\n"
                f"📅 예약된 시간: {scheduled_time}\n"
                f"📋 예약된 매물: {property_count}개\n\n"
                f"⚠️ 주의: 예약이 취소되면 자정에 자동화가 실행되지 않습니다."
            )

            if not result:
                return

            # 예약 파일 삭제
            os.remove(self.schedule_file)
            print(f"🗑️ 예약 파일 삭제: {self.schedule_file}")

            # Git 작업 실행
            self.git_cancel_schedule()

            # 상태 업데이트
            self.schedule_status.config(text="예약된 작업 없음")
            messagebox.showinfo("완료", f"최적화 예약이 취소되었습니다.\n\n 자동화가 실행되지 않습니다.")

        except Exception as e:
            messagebox.showerror("오류", f"예약 취소 실패: {e}")

    def git_cancel_schedule(self):
        """예약 취소를 위한 Git commit & push"""
        try:
            # 현재 디렉토리 저장
            original_dir = os.getcwd()
            
            # Git 저장소로 이동
            os.chdir(self.github_repo_path)
            print(f"📁 Git 저장소로 이동: {self.github_repo_path}")
            
            # Git add (삭제된 파일 반영)
            subprocess.run(['git', 'add', 'data/scheduled_properties.json'], 
                         check=True, capture_output=True, text=True)
            print("✅ Git add 완료 (삭제 반영)")

            # Git commit
            commit_message = f"🗑️ 자동화 예약 취소 ({datetime.now().strftime('%Y-%m-%d %H:%M')})"
            subprocess.run(['git', 'commit', '-m', commit_message], 
                         check=True, capture_output=True, text=True)
            print("✅ Git commit 완료")

            # Git push
            subprocess.run(['git', 'push'], 
                         check=True, capture_output=True, text=True)
            print("✅ Git push 완료")

            print(f"🗑️ 예약 취소 완료!")

        except subprocess.CalledProcessError as e:
            if e.stderr and "nothing to commit" in e.stderr:
                print("ℹ️ 이미 예약이 취소된 상태입니다.")
            else:
                error_msg = f"Git 명령어 실행 실패: {e.stderr if e.stderr else str(e)}"
                print(f"❌ {error_msg}")
                raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Git 작업 중 오류: {str(e)}"
            print(f"❌ {error_msg}")
            raise Exception(error_msg)
        finally:
            # 원래 디렉토리로 복원
            os.chdir(original_dir)

    def check_existing_schedules(self):
        """기존 GitHub 예약 상태 확인 및 표시 (날짜 비교 포함)"""
        try:
            if os.path.exists(self.schedule_file):
                with open(self.schedule_file, 'r', encoding='utf-8') as f:
                    schedule_data = json.load(f)
                
                # 예약 생성 날짜와 현재 날짜 비교
                scheduled_at_str = schedule_data.get('scheduled_at', '')
                if scheduled_at_str:
                    try:
                        scheduled_date = datetime.fromisoformat(scheduled_at_str).date()
                        today = datetime.now().date()
                        
                        # 예약이 오늘이 아닌 다른 날에 생성된 경우 기본값으로 표시
                        if scheduled_date != today:
                            print(f"📅 예약 파일이 다른 날짜({scheduled_date})에 생성됨. 기본 상태로 표시.")
                            self.schedule_status.config(text="예약된 작업 없음")
                            return
                            
                    except:
                        print("⚠️ 예약 날짜 파싱 실패. 기본 상태로 표시.")
                        self.schedule_status.config(text="예약된 작업 없음")
                        return
                
                # 오늘 생성된 예약이면 정상 표시
                target_time_str = schedule_data.get('target_time', '')
                property_count = len(schedule_data.get('properties', []))
                
                if target_time_str:
                    try:
                        target_time = datetime.fromisoformat(target_time_str)
                        status_text = f"🚀 최적화 예약됨: {target_time.strftime('%m-%d %H:%M')}에 {property_count}개 매물"
                        self.schedule_status.config(text=status_text)
                        print(f"📅 오늘 생성된 GitHub 예약 발견: {status_text}")
                    except:
                        print(f"❌ 예약 시간 파싱 실패: {target_time_str}")
            else:
                self.schedule_status.config(text="예약된 작업 없음")

        except Exception as e:
            print(f"❌ 기존 예약 확인 실패: {e}")
            self.schedule_status.config(text="예약된 작업 없음")

        

    def real_automation(self):
        """실제 자동화 실행 (로컬에서 즉시 실행)"""
        selected_properties = [
            data['article_no'] for data in self.property_selections.values()
            if data['selected']
        ]

        if not selected_properties:
            messagebox.showwarning("경고", "선택된 매물이 없습니다.")
            return

        # 확인 대화상자
        result = messagebox.askyesno(
            "즉시 자동화 실행",
            f"⚠️ 로컬에서 즉시 {len(selected_properties)}개 매물의 자동화를 실행하시겠습니까?\n\n"
            f"📊 매물번호: {', '.join(selected_properties)}\n\n"
            f"🚀 이 작업은 로컬 컴퓨터에서 실제 사이트 자동화를 진행합니다.\n"
            f"⏱️ 예상 소요시간: 약 {len(selected_properties) * 1}분"
        )

        if not result:
            return

        # 로딩 스피너 시작
        self.spinner.text = "🚀 즉시 자동화 실행 중... (시간이 오래 걸릴 수 있습니다)"
        self.spinner.start(self.status_label)
        self.set_buttons_state('disabled')

        def real_thread():
            try:
                print(f"🚀 즉시 자동화 시작: {len(selected_properties)}개 매물")
                print(f"📋 매물번호: {', '.join(selected_properties)}")

                from property_update import RealEstateAutomation
                automation = RealEstateAutomation(headless=True)  # 헤드리스 모드로 실행

                import asyncio
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(
                    automation.run_automation(selected_properties))
                loop.close()

                self.root.after(0, lambda: self.finish_real_automation(
                    len(selected_properties)))

                print("🚀 즉시 자동화 완료")

            except Exception as e:
                error_msg = f"즉시 자동화 실패: {str(e)}"
                self.root.after(
                    0, lambda: self.finish_real_automation_error(error_msg))
                print(f"❌ {error_msg}")

        threading.Thread(target=real_thread, daemon=True).start()

    def finish_real_automation(self, count):
        """즉시 자동화 완료 처리"""
        self.spinner.stop()
        self.set_buttons_state('normal')
        self.status_label.config(text="🚀 즉시 자동화 완료!")
        messagebox.showinfo(
            "완료", f"{count}개 매물 즉시 자동화 완료!\n\n사이트에서 결과를 확인해보세요.")

    def finish_real_automation_error(self, error_msg):
        """즉시 자동화 에러 처리"""
        self.spinner.stop()
        self.set_buttons_state('normal')
        self.status_label.config(text=f"❌ {error_msg}")
        messagebox.showerror("오류", error_msg)

    def load_existing_data(self):
        """기존 데이터 로드"""
        if os.path.exists(self.ranking_data_file):
            try:
                with open(self.ranking_data_file, 'r', encoding='utf-8') as f:
                    results = json.load(f)
                self.update_property_list(results)
                self.status_label.config(
                    text=f"기존 데이터 로드됨 ({len(results)}개 매물)")
            except:
                pass

        # 기존 GitHub 예약 상태 확인
        self.check_existing_schedules()

    def run(self):
        """GUI 실행"""
        try:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.mainloop()
        except KeyboardInterrupt:
            print("프로그램 종료")

    def on_closing(self):
        """프로그램 종료 처리"""
        # GitHub 예약이 있는지 확인 (날짜 비교 포함)
        has_github_schedule = self.check_valid_schedule_exists()

        if has_github_schedule:
            result = messagebox.askyesno(
                "프로그램 종료 확인",
                "ℹ️ 최적화 예약이 설정되어 있습니다.\n\n"
                "프로그램을 종료해도 자동으로 실행됩니다.\n"
                "종료하시겠습니까?"
            )
            if not result:
                return

        self.root.destroy()

    def check_valid_schedule_exists(self):
        """유효한 예약이 있는지 확인 (오늘 생성된 것만)"""
        try:
            if not os.path.exists(self.schedule_file):
                return False
                
            with open(self.schedule_file, 'r', encoding='utf-8') as f:
                schedule_data = json.load(f)
            
            # 예약 생성 날짜와 현재 날짜 비교
            scheduled_at_str = schedule_data.get('scheduled_at', '')
            if scheduled_at_str:
                try:
                    scheduled_date = datetime.fromisoformat(scheduled_at_str).date()
                    today = datetime.now().date()
                    return scheduled_date == today  # 오늘 생성된 예약만 유효
                except:
                    return False
            return False
            
        except Exception as e:
            return False


if __name__ == "__main__":
    print("🚀 매물 자동화 시스템 시작 (GitHub Actions 연동)")
    
    # 환경변수 확인
    required_vars = ['LOGIN_ID', 'LOGIN_PASSWORD', 'REALTOR_ID']
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        print(f"❌ 환경변수 누락: {', '.join(missing_vars)}")
        print("📝 .env 파일에 다음 정보를 설정해주세요:")
        for var in missing_vars:
            print(f"   {var}=your_value")
        input("엔터를 눌러 종료...")
        exit(1)
    
    print("✅ 환경변수 설정 확인 완료")
    print(f"📁 GitHub 저장소 경로: {os.getenv('GITHUB_REPO_PATH', '기본 경로 사용')}")
    print("🚀 GitHub Actions를 통해 절전모드와 관계없이 자동 실행됩니다!")
    
    app = SimplePropertyManager()
    app.run()