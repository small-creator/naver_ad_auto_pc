# 🏆 네이버부동산 매물 자동화 - 로컬 클라이언트

이 패키지는 매물 자동화 시스템의 로컬 GUI 클라이언트입니다.

## 📋 포함된 파일

- **complete_automation_system.py** - 메인 GUI 시스템
- **rank_checker.py** - 순위 조회 및 분석
- **property_update.py** - 로컬 자동화 실행
- **requirements.txt** - 필수 Python 패키지
- **run.bat** - 실행 스크립트 (Windows)

## ⚙️ 시스템 요구사항

- **Windows 10 이상**
- **Python 3.8 이상**
- **Git** (저장소 연동용)

## 🚀 설치 및 실행

### 자동 설치 (권장)
1. **install.bat** 파일 다운로드
2. **우클릭** → **"관리자 권한으로 실행"**
3. 안내에 따라 설치 진행

### 수동 설치
1. **Python 패키지 설치**
   ```bash
   pip install -r requirements.txt
   playwright install chromium
   ```

2. **.env 파일 생성**
   ```env
   LOGIN_ID=your_login_id
   LOGIN_PASSWORD=your_password
   REALTOR_ID=your_realtor_id
   GITHUB_REPO_PATH=C:\path\to\your\github\repo
   ```

3. **실행**
   - **run.bat** 더블클릭 또는
   - `python complete_automation_system.py`

## 🔧 사용법

1. **📊 순위 조회** - 현재 매물 순위 분석
2. **매물 선택** - 체크박스로 원하는 매물 선택  
3. **⏰ 최적화 예약** - GitHub Actions 예약
4. **🚀 즉시 실행** - 로컬에서 바로 실행

## 📞 문제해결

### Python 실행 오류
```
'python' is not recognized...
```
→ Python 설치 시 "Add to PATH" 체크 확인

### .env 파일 오류  
```
❌ .env 파일이 없습니다.
```
→ .env 파일을 프로그램과 같은 폴더에 생성

### GitHub 연동 오류
```
❌ Git 작업 실패
```
→ GITHUB_REPO_PATH 경로 및 Git 설치 확인

## 🔒 보안

- 로그인 정보는 .env 파일에 안전하게 저장
- GitHub Secrets와 연동하여 이중 보안
- 민감한 정보는 절대 코드에 하드코딩하지 않음

## 📄 라이선스

개인 사용 목적으로 제작되었습니다. 사용 시 관련 사이트의 이용약관을 준수해주세요.