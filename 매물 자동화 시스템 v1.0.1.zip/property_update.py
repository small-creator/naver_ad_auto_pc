import asyncio
import os
from datetime import datetime
from playwright.async_api import async_playwright
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

class RealEstateAutomation:
    def __init__(self, headless=True):
        self.headless = headless
        
        # 환경변수에서 로그인 정보 가져오기
        self.login_id = os.getenv('LOGIN_ID')
        self.login_pw = os.getenv('LOGIN_PASSWORD')
        
        # 환경변수가 없는 경우 에러 처리
        if not self.login_id or not self.login_pw:
            raise ValueError("LOGIN_ID와 LOGIN_PASSWORD를 .env 파일에 설정해주세요.")
        
        self.login_url = "https://www.aipartner.com/integrated/login?serviceCode=1000"
        self.ad_list_url = "https://www.aipartner.com/offerings/ad_list"
        
        print(f"🔧 로그인 ID: {self.login_id}")
        print(f"🔒 비밀번호: {'*' * len(self.login_pw)}")  # 보안을 위해 마스킹
        
    async def login(self, page):
        """로그인 처리"""
        print("로그인 페이지로 이동 중...")
        
        await page.goto(self.login_url, timeout=60000)
        await page.wait_for_selector('#member-id', timeout=30000)
        
        await page.fill('#member-id', self.login_id)
        await page.fill('#member-pw', self.login_pw)
        await page.click('#integrated-login > a')
        
        await page.wait_for_timeout(3000)
        print("로그인 완료")
    
    async def find_property_and_end_exposure(self, page, property_number):
        """매물 찾기 및 노출종료 (페이지네이션 포함)"""
        print(f"매물번호 {property_number} 검색 중...")
        
        await page.goto(self.ad_list_url, timeout=60000)
        await page.wait_for_selector('table tbody tr', timeout=30000)
        
        property_found = False
        current_page = 1
        max_pages = 10
        
        while not property_found and current_page <= max_pages:
            print(f"=== {current_page}페이지에서 매물 검색 중 ===")
            
            rows = await page.query_selector_all('#wrap > div > div > div > div.sectionWrap > div.singleSection.listSection > div.listWrap > table > tbody > tr')
            print(f"{current_page}페이지: 총 {len(rows)}개의 매물을 확인합니다.")
            
            for i, row in enumerate(rows, 1):
                number_cell = await row.query_selector('td:nth-child(3) > div.numberN')
                if number_cell:
                    number_text = await number_cell.inner_text()
                    if property_number in number_text.strip():
                        print(f"매물번호 {property_number} 발견! ({current_page}페이지, 행: {i})")
                        
                        end_button = await row.query_selector('#naverEnd')
                        if end_button:
                            await end_button.click()
                            print("노출종료 버튼 클릭 완료")
                            await page.wait_for_timeout(2000)
                            property_found = True
                            break
                        else:
                            print("노출종료 버튼을 찾을 수 없습니다.")
            
            if property_found:
                break
            
            # 다음 페이지로 이동
            next_button = await page.query_selector('#wrap > div > div > div > div.sectionWrap > div.singleSection.listSection > div.pagination > span:nth-child(5) > a')
            if next_button:
                button_class = await next_button.get_attribute('class')
                if button_class and 'disabled' in button_class:
                    print("마지막 페이지에 도달했습니다.")
                    break
                
                await next_button.click()
                await page.wait_for_timeout(3000)
                current_page += 1
            else:
                print("다음 페이지 버튼을 찾을 수 없습니다.")
                break
        
        if not property_found:
            print(f"매물번호 {property_number}를 찾을 수 없습니다.")
            return False
        
        # 광고종료 버튼 클릭
        ad_end_button = await page.wait_for_selector('#wrap > div > div > div > div.sectionWrap > div.statusWrap.ver3 > div.statusItem.statusAdEnd.GTM_offerings_ad_list_end_ad', timeout=10000)
        await ad_end_button.click()
        print("광고종료 버튼 클릭 완료 - 종료매물 목록 표시")
        await page.wait_for_timeout(3000)
        
        # 종료매물에서 재광고 버튼 클릭
        end_rows = await page.query_selector_all('#wrap > div > div > div > div.sectionWrap > div.singleSection.listSection > div.listWrap > table > tbody > tr')
        
        for row in end_rows:
            number_cell = await row.query_selector('td:nth-child(3) > div.numberN')
            if number_cell:
                number_text = await number_cell.inner_text()
                if property_number in number_text.strip():
                    print(f"종료매물에서 매물번호 {property_number} 발견!")
                    
                    re_ad_button = await row.query_selector('#reReg')
                    if re_ad_button:
                        await re_ad_button.click()
                        print("재광고 버튼 클릭 완료")
                        await page.wait_for_timeout(3000)
                        return True
        
        print(f"종료매물에서 매물번호 {property_number}를 찾을 수 없습니다.")
        return False
    
    async def process_ad_regist(self, page):
        """광고등록 페이지 처리"""
        print("광고등록 페이지 처리 중...")
        
        await page.wait_for_url('**/offerings/ad_regist', timeout=30000)
        await page.wait_for_timeout(2000)
        
        # 광고하기 버튼 클릭
        try:
            await page.click('text=광고하기')
            print("광고하기 버튼 클릭 완료")
        except:
            ad_button = await page.query_selector('button:has-text("광고하기"), input[value*="광고"], a:has-text("광고하기")')
            if ad_button:
                await ad_button.click()
                print("광고하기 버튼 클릭 완료")
            else:
                print("광고하기 버튼을 찾을 수 없습니다.")
                return False
        
        await page.wait_for_timeout(2000)
        return True
    
    async def process_payment(self, page):
        """결제 처리"""
        print("결제 페이지에서 처리 중...")
        
        await page.wait_for_timeout(3000)
        
        # 체크박스 클릭
        await page.evaluate("document.querySelector('#consentMobile2').click()")
        print("체크박스 클릭 완료")
        
        await page.wait_for_timeout(1000)
        
        # 결제하기 버튼 클릭
        payment_button = await page.query_selector('#naverSendSave')
        if payment_button:
            await payment_button.click()
            print("결제하기 버튼 클릭 완료")
        else:
            print("결제하기 버튼을 찾을 수 없습니다.")
            return False
        
        await page.wait_for_timeout(3000)
        return True
    
    async def return_to_list(self, page):
        """매물검증 페이지에서 목록으로 돌아가기"""
        print("목록 버튼 클릭하여 매물리스트로 돌아가는 중...")
        
        try:
            # 목록 버튼 클릭
            list_button = await page.wait_for_selector('#btnCancel', timeout=10000)
            if list_button:
                await list_button.click()
                print("목록 버튼 클릭 완료")
                await page.wait_for_timeout(3000)
                return True
            else:
                print("목록 버튼을 찾을 수 없습니다.")
                return False
        except Exception as e:
            print(f"목록 버튼 클릭 실패: {e}")
            return False
    
    async def process_single_property(self, page, property_number):
        """단일 매물 처리 (목록 버튼 실패 시에도 성공으로 처리)"""
        print(f"\n{'='*50}")
        print(f"매물번호 {property_number} 처리 시작")
        print(f"{'='*50}")
        
        try:
            # 1. 매물 찾기 및 노출종료
            if await self.find_property_and_end_exposure(page, property_number):
                # 2. 광고등록 페이지 처리
                if await self.process_ad_regist(page):
                    # 3. 결제 처리
                    if await self.process_payment(page):
                        print(f"✅ 매물번호 {property_number} 핵심 처리 완료!")
                        
                        # 4. 목록으로 돌아가기 (실패해도 전체 성공으로 처리)
                        try:
                            if await self.return_to_list(page):
                                print(f"✅ 목록 페이지로 이동 완료")
                                return True
                            else:
                                print(f"⚠️ 목록 페이지 이동 실패 (하지만 매물 처리는 성공)")
                                # 강제로 목록 페이지로 이동 시도
                                try:
                                    await page.goto(self.ad_list_url, timeout=30000)
                                    await page.wait_for_timeout(2000)
                                    print(f"✅ 강제 목록 페이지 이동 완료")
                                except Exception as nav_error:
                                    print(f"⚠️ 강제 목록 페이지 이동도 실패: {nav_error}")
                                
                                # 매물 처리 자체는 성공했으므로 True 반환
                                return True
                        except Exception as list_error:
                            print(f"⚠️ 목록 이동 중 예외 발생: {list_error}")
                            print(f"✅ 하지만 매물 처리는 성공했으므로 성공으로 처리")
                            
                            # 강제로 목록 페이지로 이동 시도
                            try:
                                await page.goto(self.ad_list_url, timeout=30000)
                                await page.wait_for_timeout(2000)
                                print(f"✅ 강제 목록 페이지 이동 완료")
                            except:
                                print(f"⚠️ 강제 목록 페이지 이동도 실패")
                            
                            return True  # 매물 처리는 성공
                    else:
                        print(f"❌ 결제 처리 중 오류가 발생했습니다.")
                        return False
                else:
                    print(f"❌ 광고등록 처리 중 오류가 발생했습니다.")
                    return False
            else:
                print(f"❌ 매물을 찾을 수 없습니다.")
                return False
            
    except Exception as e:
        print(f"❌ 매물번호 {property_number} 처리 중 오류 발생: {e}")
        return False
    
    async def run_automation(self, property_numbers, max_retries=2):
        """전체 자동화 프로세스 실행 (전체 처리 후 실패 매물 재시도)"""
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.headless, slow_mo=1000)
            context = await browser.new_context()
            page = await context.new_page()
            
            # Alert 창 자동 처리
            page.on('dialog', lambda dialog: dialog.accept())
            
            try:
                # 로그인 (한 번만)
                await self.login(page)
                
                # 전체 결과 추적
                total_success = 0
                failed_properties = []
                
                # === 1단계: 전체 매물 초기 처리 ===
                print(f"\n{'='*60}")
                print(f"📋 1단계: 전체 {len(property_numbers)}개 매물 처리 시작")
                print(f"{'='*60}")
                
                for i, property_number in enumerate(property_numbers, 1):
                    print(f"\n[{i}/{len(property_numbers)}] 매물 처리 중...")
                    
                    if await self.process_single_property(page, property_number):
                        total_success += 1
                        print(f"✅ 매물번호 {property_number} 성공")
                    else:
                        failed_properties.append(property_number)
                        print(f"❌ 매물번호 {property_number} 실패 (재시도 대상)")
                        
                        # 실패한 경우에도 매물리스트 페이지로 돌아가기 시도
                        try:
                            await page.goto(self.ad_list_url, timeout=30000)
                            await page.wait_for_timeout(2000)
                        except:
                            print("매물리스트 페이지로 강제 이동 실패")
                
                # 1단계 결과 출력
                print(f"\n{'='*60}")
                print(f"📊 1단계 처리 완료")
                print(f"✅ 성공: {total_success}개")
                print(f"❌ 실패: {len(failed_properties)}개")
                if failed_properties:
                    print(f"🔄 재시도 대상: {', '.join(failed_properties)}")
                print(f"{'='*60}")
                
                # === 2단계: 실패 매물 재시도 ===
                retry_round = 1
                
                while failed_properties and retry_round <= max_retries:
                    print(f"\n{'='*60}")
                    print(f"🔄 재시도 {retry_round}단계: {len(failed_properties)}개 매물 처리")
                    print(f"{'='*60}")
                    
                    current_retry_failed = []
                    
                    for i, property_number in enumerate(failed_properties, 1):
                        print(f"\n[재시도 {i}/{len(failed_properties)}] 매물번호 {property_number} 재처리 중...")
                        
                        if await self.process_single_property(page, property_number):
                            total_success += 1
                            print(f"✅ 매물번호 {property_number} 재시도 성공!")
                        else:
                            current_retry_failed.append(property_number)
                            print(f"❌ 매물번호 {property_number} 재시도 실패")
                            
                            # 실패한 경우에도 매물리스트 페이지로 돌아가기 시도
                            try:
                                await page.goto(self.ad_list_url, timeout=30000)
                                await page.wait_for_timeout(2000)
                            except:
                                print("매물리스트 페이지로 강제 이동 실패")
                    
                    # 재시도 결과 출력
                    retry_success = len(failed_properties) - len(current_retry_failed)
                    print(f"\n📊 재시도 {retry_round}단계 완료")
                    print(f"✅ 재시도 성공: {retry_success}개")
                    print(f"❌ 재시도 실패: {len(current_retry_failed)}개")
                    
                    # 다음 재시도를 위해 실패 목록 업데이트
                    failed_properties = current_retry_failed
                    retry_round += 1
                    
                    # 다음 재시도가 있다면 잠시 대기
                    if failed_properties and retry_round <= max_retries:
                        print(f"\n⏱️  다음 재시도 전 5초 대기...")
                        await page.wait_for_timeout(5000)
                
                # === 최종 결과 출력 ===
                print(f"\n{'='*80}")
                print(f"🏁 전체 자동화 프로세스 완료!")
                print(f"{'='*80}")
                print(f"📊 총 처리 매물: {len(property_numbers)}개")
                print(f"✅ 최종 성공: {total_success}개")
                print(f"❌ 최종 실패: {len(failed_properties)}개")
                print(f"📈 성공률: {(total_success/len(property_numbers)*100):.1f}%")
                
                if failed_properties:
                    print(f"❌ 최종 실패 매물번호: {', '.join(failed_properties)}")
                    print(f"💡 이 매물들은 {max_retries}회 재시도 후에도 실패했습니다.")
                else:
                    print(f"🎉 모든 매물이 성공적으로 처리되었습니다!")
                
                print(f"🔄 총 재시도 단계: {min(retry_round-1, max_retries)}회")
                print(f"{'='*80}")
                
                await page.wait_for_timeout(5000)
                
            except Exception as e:
                print(f"자동화 프로세스 중 오류 발생: {e}")
            finally:
                await browser.close()

# 실행 함수
async def main():
    try:
        automation = RealEstateAutomation()
        
        print("매물번호를 입력하세요 (여러 개인 경우 콤마로 구분):")
        property_input = input("예) 12345678 또는 12345678,87654321,11111111: ")
        
        if property_input.strip():
            # 콤마로 구분된 매물번호들을 리스트로 변환
            property_numbers = [num.strip() for num in property_input.split(',') if num.strip()]
            
            if property_numbers:
                print(f"\n처리할 매물번호: {', '.join(property_numbers)}")
                await automation.run_automation(property_numbers)
            else:
                print("올바른 매물번호를 입력해주세요.")
        else:
            print("매물번호를 입력해주세요.")
            
    except ValueError as e:
        print(f"❌ 설정 오류: {e}")
    except Exception as e:
        print(f"❌ 실행 오류: {e}")

if __name__ == "__main__":
    asyncio.run(main())